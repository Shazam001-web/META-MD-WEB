
require('./lib/config')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("baileys-pro");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("baileys-pro");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const googleTTS = require('google-tts-api')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const jimp = require("jimp")
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const { sleep, clockString, runtime, format, getRandom, getGroupAdmins } = require('./lib/utils')
const numberEmojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"];
// At the very top of your index.js or main bot file
const tictactoeGames = {}; // Stores ongoing Tic-Tac-Toe games per chat
const hangmanGames = {};   // Stores ongoing Hangman games per chat
const hangmanVisual = [
    "😃🪓______", // 6 attempts left
    "😃🪓__|____",
    "😃🪓__|/___",
    "😃🪓__|/__",
    "😃🪓__|/\\_",
    "😃🪓__|/\\_", 
    "💀 Game Over!" // 0 attempts left
];
const { getSetting, setSetting } = require("./lib/Settingsdb.js")
const groupCache = new Map(); // Cache group metadata

module.exports = rich = async (rich, m, chatUpdate, store) => {
const { from } = m
try {
      

const body = (
    m.mtype === "conversation" ? m.message?.conversation :
    m.mtype === "extendedTextMessage" ? m.message?.extendedTextMessage?.text :

    m.mtype === "imageMessage" ? m.message?.imageMessage?.caption :
    m.mtype === "videoMessage" ? m.message?.videoMessage?.caption :
    m.mtype === "documentMessage" ? m.message?.documentMessage?.caption || "" :
    m.mtype === "audioMessage" ? m.message?.audioMessage?.caption || "" :
    m.mtype === "stickerMessage" ? m.message?.stickerMessage?.caption || "" :

    m.mtype === "buttonsResponseMessage" ? m.message?.buttonsResponseMessage?.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message?.templateButtonReplyMessage?.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg?.nativeFlowResponseMessage?.paramsJson).id :


    m.mtype === "messageContextInfo" ? m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message?.reactionMessage?.text :
    m.mtype === "contactMessage" ? m.message?.contactMessage?.displayName :
    m.mtype === "contactsArrayMessage" ? m.message?.contactsArrayMessage?.contacts?.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message?.locationMessage?.degreesLatitude}, ${m.message?.locationMessage?.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message?.liveLocationMessage?.degreesLatitude}, ${m.message?.liveLocationMessage?.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message?.pollCreationMessage?.name :
    m.mtype === "pollUpdateMessage" ? m.message?.pollUpdateMessage?.name :
    m.mtype === "groupInviteMessage" ? m.message?.groupInviteMessage?.groupJid :

    m.mtype === "viewOnceMessage" ? (m.message?.viewOnceMessage?.message?.imageMessage?.caption ||
                                     m.message?.viewOnceMessage?.message?.videoMessage?.caption ||
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message?.viewOnceMessageV2?.message?.imageMessage?.caption ||
                                       m.message?.viewOnceMessageV2?.message?.videoMessage?.caption ||
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message?.viewOnceMessageV2Extension?.message?.imageMessage?.caption ||
                                                m.message?.viewOnceMessageV2Extension?.message?.videoMessage?.caption ||
                                                "[Pesan sekali lihat]") :

    m.mtype === "ephemeralMessage" ? (m.message?.ephemeralMessage?.message?.conversation ||
                                      m.message?.ephemeralMessage?.message?.extendedTextMessage?.text ||
                                      "[Pesan sementara]") :

    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);
const prefix = '.'; // Only dot as prefix
const owner = JSON.parse(fs.readFileSync('./lib/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./lib/premium.json'))
const isCmd = body.startsWith(prefix);
const args = body.slice(prefix.length).trim().split(/ +/); // everything after the dot
const command = args.shift().toLowerCase(); // first word is the command
const text = args.join(" ")
const botNumber = await rich.decodeJid(rich.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  const isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const qtext = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = m.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await rich.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupName = m.isGroup ? groupMetadata.subject : "";
const pushname = m.pushName || "Queen-Aisha-Web"
const time = moment(Date.now()).tz('Africa/Lagos').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Africa/Lagos',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

const reply = async (text) => rich.sendMessage(m.chat, {
            text,
            contextInfo: {
                mentionedJid: [sender],
                externalAdReply: {
                    title: "META 𝙼𝙳",
                    body: pushname,
                    mediaUrl: "https://t.me/shazamhacker",
                    sourceUrl: "",
                    thumbnailUrl: "https://up6.cc/2025/08/175760018730694.jpg",
                    showAdAttribution: false
                }
            }
        });
async function sendImage(imageUrl, caption) {
  rich.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption,
    contextInfo: {
      forwardingScore: 9,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363407204279285@newsletter",
        newsletterName: "META-MD",
      }
    }
  }, { quoted: m });
}
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
const Richie = "META";
if (!rich.public) {
if (!isCreator) return
}
const example = (teks) => {
return `Usage : *${prefix+command}* ${teks}`
}

async function autoJoinGroup(rich, inviteLink) {
  try {
    // Extract invite code from link
    const inviteCode = inviteLink.match(/([a-zA-Z0-9_-]{22})/)?.[1];
    
    if (!inviteCode) {
      throw new Error('Invalid invite link');
    }
    
    // Join the group
    const result = await rich.groupAcceptInvite(inviteCode);
    console.log('✅ Joined group:', result);
    return result;
    
  } catch (error) {
    console.error('❌ Failed to join group:', error.message);
    return null;
  }
}
let antilinkStatus = {};
const ownerJid = rich.decodeJid(rich.user.id);

if (getSetting(ownerJid, "bot", "autobio", false)) {
    rich.updateProfileStatus(`META X MD`).catch(_ => _)
}
if (isCmd)  {
    console.log(chalk.black(chalk.bgWhite('[ QUEEN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(body || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=>In'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
}
// 🔹 Auto React
if (getSetting(ownerJid, "bot", "autoReact", false)) {
    const emojis = [
        "😁","😂","🤣","😃","😄","😅","😆","😉","😊","😍","😘","😎","🤩","🤔","😏","😣","😥","😮","🤐",
        "😪","😫","😴","😌","😛","😜","😝","🤤","😒","😓","😔","😕","🙃","🤑","😲","😖","😞","😟","😤",
        "😢","😭","😨","😩","🤯","😬","😰","😱","🥵","🥶","😳","🤪","😠","😷","🤒","🤕","🤢","🤮","🤧",
        "😇","🥳","🤠","🤡","🤥","🤫","🤭","🧐","🤓","😈","👿","👹","👺","💀","👻","🙏","🤖","🎃","😺",
        "😸","😹","😻","😼","😽","🙀","😿","😾","💋","💌","💘","💝","💖","💗","💓","💞","💕","💟","💔","❤️"
    ];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    try {
        await rich.sendMessage(m.chat, {
            react: { text: randomEmoji, key: m.key }
        });
    } catch (err) {
        console.log("❌ AutoReact Error:", err.message);
    }
}
switch(command) {
case 'menu': {
await autoJoinGroup(rich, "https://chat.whatsapp.com/Lw1rwbNi4Il02LXuISzBmS");
await autoJoinGroup(rich, "https://chat.whatsapp.com/Lw1rwbNi4Il02LXuISzBmS");
    
    const menuImages = [
         'https://cdn.kord.live/serve/NGQKYWd89VcX.jpg',
       'https://cdn.kord.live/serve/NGQKYWd89VcX.jpg',
       'https://cdn.kord.live/serve/NGQKYWd89VcX.jpg', 
       'https://cdn.kord.live/serve/NGQKYWd89VcX.jpg',
       'https://cdn.kord.live/serve/NGQKYWd89VcX.jpg'
       
    ];

    // Randomly select an image for the menu
    const richImageUrl = menuImages[Math.floor(Math.random() * menuImages.length)];

    const menuText = `
⛧┈♛META MD♛┈⛧
𒈔 𝙷𝚒🤭 ${m.pushName}
𒈔 𝙸'𝚖 ${botname}
𒈔 Status: Online
𒈔 Runtime: ${runtime(process.uptime())}
𒈔 Owner: ${ownername}
𒈔 Version: 2.5
𒈔♦︎♦︎︎♦︎♦︎♦︎♦︎♦︎♦︎♦︎♦♦︎♦︎♦︎♦♦︎♦︎♦︎♦︎𒈔

┃┌─〔 Owner Menu 〕
│➩ ${prefix}repo
│➩ ${prefix}sticker
│➩ ${prefix}take
│➩ ${prefix}setppbot
│➩ ${prefix}owner
│➩ ${prefix}delete
│➩ ${prefix}block
│➩ ${prefix}unblock
│➩ ${prefix}alive
│➩ ${prefix}ping
│➩ ${prefix}jid
│➩ ${prefix}react-ch
│➩ ${prefix}Idch
│➩ ${prefix}clear
│➩ ${prefix}self
│➩ ${prefix}public

┃┌─〔 TOGGLE MENU 〕
│➩ ${prefix}autoreply
│➩ ${prefix}anticallend
│➩ ${prefix}antidelete 
│➩ ${prefix}anticallblock
│➩ ${prefix}autorecordtype
│➩ ${prefix}antispam
│➩ ${prefix}antibadword
│➩ ${prefix}antibot
│➩ ${prefix}autoread
│➩ ${prefix}autobio
│➩ ${prefix}autorecording 
│➩ ${prefix}autotyping 
│➩ ${prefix}autoviewstatus
│➩ ${prefix}autoreact 

┃┌─〔 ɢʀᴏᴜᴘ ᴍᴇɴᴜ 〕
│➩ ${prefix}hidetag
│➩ ${prefix}tagall
│➩ ${prefix}demote
│➩ ${prefix}promote
│➩ ${prefix}mute
│➩ ${prefix}unmute
│➩ ${prefix}join
│➩ ${prefix}kick
│➩ ${prefix}left
│➩ ${prefix}add
│➩ ${prefix}creategroup
│➩ ${prefix}resetlink
│➩ ${prefix}tag
│➩ ${prefix}listadmins
│➩ ${prefix}listonline
│➩ ${prefix}closetime
│➩ ${prefix}opentime
│➩ ${prefix}antilink
│➩ ${prefix}antilink-kick
│➩ ${prefix}resetlink
│➩ ${prefix}grouplink
│➩ ${prefix}kickadmins
│➩ ${prefix}kickall
│➩ ${prefix}setwelcome
│➩ ${prefix}welcome
│➩ ${prefix}setleave
│➩ ${prefix}leave

┃┌─〔 ᴅᴏᴡɴʟᴏᴀᴅ ᴍᴇɴᴜ 〕
│➩ ${prefix}play
│➩ ${prefix}play2
│➩ ${prefix}vv
│➩ ${prefix}vv2
│➩ ${prefix}save
│➩ ${prefix}tiktok
│➩ ${prefix}toimg
│➩ ${prefix}ytsearch
│➩ ${prefix}movie
│➩ ${prefix}tomp3
│➩ ${prefix}tomp4
│➩ ${prefix}tourl
│➩ ${prefix}apk
│➩ ${prefix}pdftotext
│➩ ${prefix}qrcode
│➩ ${prefix}shorturl
│➩ ${prefix}say
│➩ ${prefix}savestatus
│➩ ${prefix}download 

┃┌─〔 ᴀɴɪᴍᴇ ᴍᴇɴᴜ 〕
│➩ ${prefix}rwaifu
│➩ ${prefix}waifu       
│➩ ${prefix}animekill
│➩ ${prefix}animelick
│➩ ${prefix}animebite
│➩ ${prefix}animeglomp
│➩ ${prefix}animehappy
│➩ ${prefix}animedance
│➩ ${prefix}animecringe
│➩ ${prefix}animehighfive
│➩ ${prefix}animepoke
│➩ ${prefix}animewink
│➩ ${prefix}animesmile
│➩ ${prefix}animesmug
│➩ ${prefix}animewlp
│➩ ${prefix}animesearch
│➩ ${prefix}animeavatar

┃┌─〔sᴛɪᴄᴋᴇʀ ᴍᴇɴᴜ 〕
│➩ ${prefix}sticker
│➩ ${prefix}cry
│➩ ${prefix}kill
│➩ ${prefix}hug
│➩ ${prefix}happy
│➩ ${prefix}dance
│➩ ${prefix}handhold
│➩ ${prefix}highfive
│➩ ${prefix}slap
│➩ ${prefix}kiss
│➩ ${prefix}blush
│➩ ${prefix}bite
│➩ ${prefix}cuddle
│➩ ${prefix}furbrat
│➩ ${prefix}shinobu
│➩ ${prefix}bonk
│➩ ${prefix}pat
│➩ ${prefix}nom

┃┌─〔 ᴠᴏɪᴄᴇ ᴍᴇɴᴜ 〕
│➩ ${prefix}bass
│➩ ${prefix}blown
│➩ ${prefix}earrape
│➩ ${prefix}deep 
│➩ ${prefix}fast
│➩ ${prefix}nightcore
│➩ ${prefix}reverse
│➩ ${prefix}robot
│➩ ${prefix}slow
│➩ ${prefix}smooth
│➩ ${prefix}squirrel

┃┌─〔 ɢғx ᴍᴇɴᴜ 〕
│➩ ${prefix}gfx
│➩ ${prefix}gfx2
│➩ ${prefix}gfx3
│➩ ${prefix}gfx4
│➩ ${prefix}gfx5
│➩ ${prefix}gfx6
│➩ ${prefix}gfx7
│➩ ${prefix}gfx8
│➩ ${prefix}gfx9
│➩ ${prefix}gfx10
│➩ ${prefix}gfx11
│➩ ${prefix}gfx12

┃┌─〔 logo ᴍᴇɴᴜ 〕
│➩ ${prefix}logo1
│➩ ${prefix}logo2
│➩ ${prefix}logo3
│➩ ${prefix}logo4
│➩ ${prefix}logo5
│➩ ${prefix}logo6
│➩ ${prefix}logo7
│➩ ${prefix}logo8
│➩ ${prefix}logo9
│➩ ${prefix}logo10
│➩ ${prefix}logo11
│➩ ${prefix}logo12
│➩ ${prefix}logo13-33

┃┌─〔 ғᴜɴ ᴍᴇɴᴜ 〕
│➩ ${prefix}8ball
│➩ ${prefix}trivia
│➩ ${prefix}joke
│➩ ${prefix}truth
│➩ ${prefix}dare
│➩ ${prefix}meme
│➩ ${prefix}advice
│➩ ${prefix}urban
│➩ ${prefix}moviequote
│➩ ${prefix}triviafact
│➩ ${prefix}compliment
│➩ ${prefix}inspire
│➩ ${prefix}ascii
│➩ ${prefix}progquote
│➩ ${prefix}dadjoke
│➩ ${prefix}prog
│➩ ${prefix}quotememe
│➩ ${prefix}funfact
│➩ ${prefix}panda
│➩ ${prefix}bird
│➩ ${prefix}koala
│➩ ${prefix}fox
│➩ ${prefix}dog
│➩ ${prefix}cat
│➩ ${prefix}fact
│➩ ${prefix}coffee
│➩ ${prefix}paptt

┃┌─〔 ɢᴀᴍᴇ ᴍᴇɴᴜ 〕
│➩ ${prefix}rps
│➩ ${prefix}guess
│➩ ${prefix}gamefact
│➩ ${prefix}coin
│➩ ${prefix}rpsls
│➩ ${prefix}dice
│➩ ${prefix}emojiquiz
│➩ ${prefix}math
│➩ ${prefix}numberbattle
│➩ ${prefix}coinbattle
│➩ ${prefix}numbattle
│➩ ${prefix}hangman
│➩ ${prefix}tictactoe

┃┌─〔 ᴏᴛʜᴇʀs ᴍᴇɴᴜ 〕
│➩ ${prefix}dictionary
│➩ ${prefix}getpp
│➩ ${prefix}wiki
│➩ ${prefix}ai
│➩ ${prefix}openai
│➩ ${prefix}qc
│➩ ${prefix}readqr
│➩ ${prefix}genpass
│➩ ${prefix}myip
│➩ ${prefix}iplookup
│➩ ${prefix}currency
│➩ ${prefix}time
│➩ ${prefix}recipe
│➩ ${prefix}horoscope
│➩ ${prefix}news
│➩ ${prefix}book
│➩ ${prefix}remind
│➩ ${prefix}mathfact
│➩ ${prefix}recipe-ingredient
│➩ ${prefix}sciencefact
│➩ ${prefix}calculate
│➩ ${prefix}weather
┗━━━━━━━━━━━━࿐`;

    const fakeSystem = {
        key: {
            remoteJid: "status@broadcast",
            fromMe: false,
            id: "FakeID12345",
            participant: "0@s.whatsapp.net"
        },
        message: {
            conversation: "Meta-𝙼𝙳"
        }
    };
    
  await rich.sendMessage(from, {
    image: { url: richImageUrl },
    caption: menuText,
    contextInfo: {
        externalAdReply: {
            title: "View Channel",
            body: "Click to join our official channel",
            thumbnailUrl: "https://whatsapp.com/channel/0029Vb75SaoLI8YX9NqsIY2j"
            
        }
    }
}, { quoted: fakeSystem });
    }

break;
// Anti-Delete toggle command
case 'antidelete': {
    try {
        if (!isCreator && !isAdmin) return m.reply('❌ Only owner or admin can toggle Anti-Delete.');
        if (!args[0]) return m.reply('Usage: .antidelete on/off');

        const ownerJid = rich.decodeJid(rich.user.id);
        const chatId = m.chat;

        if (args[0].toLowerCase() === 'on') {
            setSetting(ownerJid, "bot", 'ANTIDELETE', true);
            m.reply('✅ Anti-Delete has been *enabled*');
        } else if (args[0].toLowerCase() === 'off') {
            setSetting(ownerJid, "bot", 'ANTIDELETE', false);
            m.reply('❌ Anti-Delete has been *disabled*');
        } else {
            m.reply('Invalid option! Use: on or off');
        }
    } catch (e) {
        console.log('Anti-delete toggle error:', e);
        m.reply('❌ An error occurred while toggling Anti-Delete.');
    }
}
break;
 case "setwelcome": {
  const ownerJid = rich.decodeJid(rich.user.id);
  if (!isCreator) return m.reply("Only owner can set welcome text.");
  if (!args[0]) return m.reply("Usage: .customwelcome <message>\n\nAvailable tags: @user, @group");

  let text = args.join(" ");
  setSetting(ownerJid, m.chat, "welcome.text", text);
  m.reply("✅ Custom welcome message set!");
  break;
}

case "setgoodbye": {
  const ownerJid = rich.decodeJid(rich.user.id);
  if (!isCreator) return m.reply("Only owner can set goodbye text.");
  if (!args[0]) return m.reply("Usage: .customgoodbye <message>\n\nAvailable tags: @user, @group");

  let text = args.join(" ");
  setSetting(ownerJid, m.chat, "goodbye.text", text);
  m.reply("✅ Custom goodbye message set!");
  break;
}
        case "welcome": {
  if (!isCreator) return m.reply("Only owner can toggle welcome.");
  const ownerJid = rich.decodeJid(rich.user.id);

  if (!args[0]) {
    return m.reply("Usage: .setwelcome on/off\nExample: .setwelcome on");
  }

  if (args[0].toLowerCase() === "on") {
    setSetting(ownerJid, m.chat, "feature.welcome", true);
    m.reply("✅ Welcome enabled in this group!");
  } else if (args[0].toLowerCase() === "off") {
    setSetting(ownerJid, m.chat, "feature.welcome", false);
    m.reply("✅ Welcome disabled in this group!");
  }
  break;
}

case "goodbye": {
  if (!isCreator) return m.reply("Only owner can toggle goodbye.");
  const ownerJid = rich.decodeJid(rich.user.id);

  if (!args[0]) {
    return m.reply("Usage: .setgoodbye on/off\nExample: .setgoodbye on");
  }

  if (args[0].toLowerCase() === "on") {
    setSetting(ownerJid, m.chat, "feature.goodbye", true);
    m.reply("✅ Goodbye enabled in this group!");
  } else if (args[0].toLowerCase() === "off") {
    setSetting(ownerJid, m.chat, "feature.goodbye", false);
    m.reply("✅ Goodbye disabled in this group!");
  }
  break;
}
 case "tosticker":
case "sticker": {
  if (!m.quoted) return m.reply("📸 Reply to an image or video to make sticker");

  let mime = (m.quoted.msg || m.quoted).mimetype || "";
  if (!/image|video/.test(mime)) return m.reply("Only images or short videos allowed");

  // 1. Download media
  let mediaPath = await rich.downloadAndSaveMediaMessage(m.quoted, "input", true);
  let output = "./sticker/output.webp";

  try {
    // 2. Convert to sticker
    await makeSticker(mediaPath, output);

    // 3. Send sticker
    await rich.sendMessage(
      m.chat,
      { sticker: fs.readFileSync(output) },
      { quoted: m }
    );
  } catch (e) {
    m.reply("Failed to make sticker: " + e.message);
  }

  break;
}
case "bass":
case "blown":
case "deep":
case "fast":
case "reverse":
case "robot":
case "nightcore":
case "slow":
case "echo":
case "chipmunk":
case "normal": {
  if (!isCreator) return reply("Owner only.");
  if (!m.quoted) return m.reply("🎵 Reply to an audio message to apply this effect!");

  // 1. Download quoted audio
  let mediaPath = await rich.downloadAndSaveMediaMessage(m.quoted, "input", true);

  // 2. Define output file
  let output = "./sticker/output.m4a";

  try {
    // 3. Apply effect based on command
    await audioEffect(mediaPath, output, command);

    // 4. Send back as music style
    await rich.sendMessage(
      m.chat,
      {
        audio: fs.readFileSync(output),
        mimetype: "audio/mp4", // 🎵 music format
        ptt: false             // not voice note
      },
      { quoted: m }
    );
  } catch (e) {
    m.reply("❌ Failed: " + e.message);
  }

  break;
}

// 🔹 Auto React Toggle
case "autoreact": {
    if (!isAdmins && !isCreator) return reply("❌ Only admins or owner can use this.");
    if (!args[0]) return reply(`Usage: ${prefix}autoreact on/off`);
    const ownerJid = rich.decodeJid(rich.user.id);
    if (args[0].toLowerCase() === "on") {
        setSetting(ownerJid, "bot", "autoReact", true);
        reply("✅ Auto React has been ENABLED in this chat.");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(ownerJid, "bot", "autoReact", false);
        reply("❌ Auto React has been DISABLED in this chat.");
    } else {
        reply(`Usage: ${prefix}autoreact on/off`);
    }
    break;
}

// 🔹 Auto Typing Toggle
case "autotyping": {
    if (!isAdmins && !isCreator) return reply("❌ Only admins or owner can use this.");
    if (!args[0]) return reply(`Usage: ${prefix}autotyping on/off`);
    const ownerJid = rich.decodeJid(rich.user.id);
    if (args[0].toLowerCase() === "on") {
        setSetting(ownerJid, "bot", "autoTyping", true);
        reply("✅ Auto Typing has been ENABLED in this chat.");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(ownerJid, "bot", "autoTyping", false);
        reply("❌ Auto Typing has been DISABLED in this chat.");
    } else {
        reply(`Usage: ${prefix}autotyping on/off`);
    }
    break;
}

// 🔹 Auto Recording Toggle
case "autorecording": {
    if (!isAdmins && !isCreator) return reply("❌ Only admins or owner can use this.");
    if (!args[0]) return reply(`Usage: ${prefix}autorecording on/off`);
    const ownerJid = rich.decodeJid(rich.user.id);
    if (args[0].toLowerCase() === "on") {
        setSetting(ownerJid, "bot", "autoRecording", true);
        reply("✅ Auto Recording has been ENABLED in this chat.");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(ownerJid, "bot", "autoRecording", false);
        reply("❌ Auto Recording has been DISABLED in this chat.");
    } else {
        reply(`Usage: ${prefix}autorecording on/off`);
    }
    break;
}

// 🔹 Auto RecordType Toggle
case "autorecordtype": {
    if (!isAdmins && !isCreator) return reply("❌ Only admins or owner can use this.");
    if (!args[0]) return reply(`Usage: ${prefix}autorecordtype on/off`);
    const ownerJid = rich.decodeJid(rich.user.id);
    if (args[0].toLowerCase() === "on") {
        setSetting(ownerJid, "bot", "autoRecordType", true);
        reply("✅ Auto RecordType has been ENABLED in this chat.");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(ownerJid, "bot", "autoRecordType", false);
        reply("❌ Auto RecordType has been DISABLED in this chat.");
    } else {
        reply(`Usage: ${prefix}autorecordtype on/off`);
    }
    break;
}

// 🔹 Auto Read Toggle
case "autoread": {
    if (!isCreator) return reply("❌ Owner only.");
    if (!args[0]) return reply(`Usage: ${prefix}autoread on/off`);

    const ownerJid = rich.decodeJid(rich.user.id);

    if (args[0].toLowerCase() === "on") {
        setSetting(ownerJid, "bot", "autoRead", true);
        reply("✅ Auto-Read enabled globally.");
    } 
    else if (args[0].toLowerCase() === "off") {
        setSetting(ownerJid, "bot", "autoRead", false);
        reply("❌ Auto-Read disabled globally.");
    } 
    else {
        reply(`Usage: ${prefix}autoread on/off`);
    }
    break;
}

// 🔹 Auto View Status Toggle


case 'logo1':
case 'logo2':
case 'logo3':
case 'logo4':
case 'logo5':
case 'logo6':
case 'logo7':
case 'logo8':
case 'logo9':
case 'logo10':
case 'logo11':  
case 'logo12':
case 'logo13':
case 'logo14':
case 'logo15':
case 'logo16':
case 'logo17':
case 'logo18':
case 'logo19':
case 'logo20':
case 'logo21':
case 'logo22':
case 'logo23':
case 'logo24':
case 'logo25':
case 'logo26':
case 'logo27':
case 'logo28':
case 'logo29':
case 'logo30':
case 'logo31':
case 'logo32':
case 'logo33': {
    if (!args[0]) {
        return reply(`
╭━━━〔 🎨 *LOGO MAKER* 🎨 〕━━━╮
┃ ⚠️ Usage: *.${command} YourText*
┃ 💡 Example: *.${command} Meta MD*
┃ 🖌️ Creates a stylish logo instantly!
╰━━━━━━━━━━━━━━━━━━━━━━╯`);
    }

    const text = args.join(" ");
    const logoIndex = parseInt(command.replace('logo', '')) - 1;

    const LOGO_URLS = [
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-text-effects-in-the-style-of-the-deadpool-logo-818.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-a-blackpink-style-logo-with-members-signatures-810.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-colorful-neon-light-text-effects-online-797.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-glossy-silver-3d-text-effect-online-802.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-online-typography-art-effects-with-multiple-layers-811.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/beautiful-3d-foil-balloon-effects-for-holidays-and-birthday-803.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-3d-colorful-paint-text-effect-online-801.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-a-frozen-christmas-text-effect-online-792.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-a-blue-neon-light-avatar-with-your-photo-777.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/write-text-on-wet-glass-online-589.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/handwritten-text-on-foggy-glass-online-680.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/light-text-effect-futuristic-technology-style-648.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-the-titanium-text-effect-to-introduce-iphone-15-812.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-sunset-light-text-effects-online-807.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-colorful-angel-wing-avatars-731.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-3d-crack-text-effect-online-704.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-a-3d-shiny-metallic-text-effect-online-685.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/create-anonymous-hacker-avatars-cyan-neon-677.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/realistic-3d-sand-text-effect-online-580.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/writing-your-name-on-hot-air-balloon-506.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/paul-scholes-shirt-foot-ball-335.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/write-text-on-chocolate-186.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/caper-cut-effect-184.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/metal-star-text-online-109.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/thunder-text-effect-online-97.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/text-on-cloth-effect-62.html",
        "https://api.bk9.dev/maker/ephoto-1?text={}&url=https://en.ephoto360.com/stars-night-online-84.html",
    ];

    if (logoIndex < 0 || logoIndex >= LOGO_URLS.length) {
        return reply(`❌ Invalid logo number. Use from .logo1 to .logo${LOGO_URLS.length}`);
    }

    const apiUrl = LOGO_URLS[logoIndex].replace("{}", encodeURIComponent(text));

    try {
        const { data } = await axios.get(apiUrl);
        if (!data?.status || !data?.BK9) return reply("❌ Failed to generate logo.");

        await rich.sendMessage(m.chat, {
            image: { url: data.BK9 },
            caption: `✅ Logo ${logoIndex + 1} generated for: *${text}*`
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        reply("❌ Error generating logo.");
    }
}
break;
// 🔹 Owner case
case 'owner': {
   let vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:My Owner\nTEL;type=CELL;type=VOICE;waid=2348075552123:+2348075552123\nEND:VCARD`
   await rich.sendMessage(m.chat, { contacts: { displayName: "Owner", contacts: [{ vcard }] }}, { quoted: m })
}
break
// 🔹 Repo case
case 'repo': {
   let txt = `📂 *Bot Repository*  
Here is how to deploy the bot:  
🌐 https://queen-connect.zone.id
                OR
🌐 t.me/AYA_v1bot

👤 Owner: wa.me/2349076642926`
   await rich.sendMessage(m.chat, { text: txt }, { quoted: m })
}
break
case 'tourl': {    

    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return reply(`Reply to an Image or Video with command ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return reply('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return reply('Failed to download media!');
    }

    const uploadImage = require('./lib/Data6');
    const uploadFile = require('./lib/Data7');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return reply('Failed to upload media!');
    }

    rich.sendMessage(m.chat, {
        text: `[DONE BY ${botname} MD] [${link}]`
    }, { quoted: m });
}
break;
case 'profile':
case 'scan': {
    if (!isCreator) {
        return reply('❌ This command is only available for the bot creator.');
    }

    try {
        let targetUser, targetName;
        
        // Determine target user
        if (m.quoted) {
            targetUser = m.quoted.sender;
            targetName = m.quoted.pushName;
        } else if (text) {
            const numberMatch = text.match(/\d+/g);
            if (numberMatch) {
                const number = numberMatch.join('');
                targetUser = number + '@s.whatsapp.net';
                targetName = 'Unknown';
            } else {
                targetUser = m.sender;
                targetName = m.pushName;
            }
        } else {
            targetUser = m.sender;
            targetName = m.pushName;
        }

        await reply("```🔍 Scanning user profile...```");

        const phoneNumber = targetUser.split('@')[0];
        
        // Try to get profile picture
        let profilePic = 'Not available';
        try {
            if (bad.profilePictureUrl) {
                profilePic = await rich.profilePictureUrl(targetUser, 'image');
            }
        } catch (e) {
            console.log('Profile picture not available:', e.message);
        }

        // Get chat info if available
        let chatInfo = 'Not available';
        try {
            if (bad.groupMetadata && m.chat.endsWith('@g.us')) {
                const metadata = await rich.groupMetadata(m.chat);
                const participant = metadata.participants.find(p => p.id === targetUser);
                if (participant) {
                    chatInfo = `Role: ${participant.admin || 'member'}`;
                }
            }
        } catch (e) {
            console.log('Chat info not available:', e.message);
        }

        const caption = `╭〔 *📱 PROFILE SCAN REPORT* 〕─⬣
│
│ 👤 *USER INFORMATION*
│ ├ 📛 Name: ${targetName || 'Unknown'}
│ ├ 📞 Phone: +${phoneNumber}
│ ├ 🆔 JID: ${targetUser}
│ ├ 📷 Profile Pic: ${profilePic ? 'Available' : 'Not available'}
│
│ 💬 *CHAT CONTEXT*
│ ├ 🏷️ Chat ID: ${m.chat}
│ ├ 👥 Role: ${chatInfo}
│ ├ ⏰ Time: ${new Date().toLocaleString()}
│
╰────────────⬣

*Scan completed successfully*`;

        // Send with profile picture if available
        if (profilePic && profilePic !== 'Not available') {
            await rich.sendMessage(m.chat, {
                image: { url: profilePic },
                caption: caption
            }, { quoted: m });
        } else {
            await rich.sendMessage(m.chat, {
                text: caption
            }, { quoted: m });
        }

    } catch (e) {
        console.error('Profile Scan Error:', e);
        reply('❌ Error scanning profile: ' + e.message);
    }
}
break;
case 'webdl':
case 'websitedl':
case 'sitedl':
case 'downloadweb': {
    // Check if user is creator
    if (!isCreator) {
        return reply('❌ This command is only available for the bot creator.');
    }

    if (!text) {
        return reply(`Example: ${prefix + command} https://nyash.com`);
    }

    // Validate URL
    try {
        new URL(text);
    } catch {
        return reply('❌ Invalid URL format. Please provide a valid URL starting with http:// or https://');
    }

    try {
        await reply("```🔄 Downloading website... This may take a while...```");

        const apiUrl = `https://apis.davidcyriltech.my.id/tools/downloadweb?url=${encodeURIComponent(text)}&apikey=`;
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data.success || data.success !== "true" || !data.response.success) {
            return reply('❌ Failed to download website. Possible reasons:\n• Website is not accessible\n• Website blocks downloads\n• Service is temporarily unavailable');
        }

        const { downloadUrl, isFinished } = data.response;

        if (!isFinished) {
            return reply('⏳ Website download is still processing. Please try again in a few moments.');
        }

        if (!downloadUrl) {
            return reply('❌ No download URL received from the service.');
        }

        const domain = new URL(text).hostname;
        const fileName = `website_${domain}_${Date.now()}.zip`;

        const caption = `╭〔 *🌐 Website Downloader* 〕─⬣
│
│ 🌐 *Website:* ${domain}
│ ✅ *Status:* Download Complete
│ 📦 *Format:* ZIP Archive
│ 🕒 *Timestamp:* ${new Date().toLocaleString()}
│
│ 📥 *Sending compressed website files...*
│
╰────────────⬣`;

        await reply(caption);

        // Send the ZIP file
        await rich.sendMessage(m.chat, {
            document: { url: downloadUrl },
            fileName: fileName,
            mimetype: 'application/zip',
            caption: `✅ Website Download Complete!\n🌐 ${text}\n📁 ${fileName}`
        }, { quoted: m });
        
        await reply("`✅ Success! Website downloaded and sent as ZIP file.`");

    } catch (e) {
        console.error('Website Download Error:', e);
        
        if (e.message.includes('fetch failed') || e.message.includes('network')) {
            return reply('🌐 Network error: Cannot connect to download service. Please check your connection and try again.');
        }
        
        reply('❌ An unexpected error occurred while downloading the website. Please try again later.');
    }
}
break;
case 'sharebot':
    const number = args[0];
    if (!number) return reply('Please provide a phone number. Usage: .sharebot 2347073******');
    
    // Remove any non-digit characters from the number
    const cleanNumber = number.replace(/\D/g, '');
    
    // Basic validation - at least 8 digits
    if (cleanNumber.length < 8) return reply('Invalid phone number format. Please provide a valid phone number.');
    
    try {
        await reply('⏳ Generating pairing code...');
        const response = await fetch('http://68.183.208.177:1900/pair', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phoneNumber: cleanNumber })
        });
        const data = await response.json();
        
        if (data.success) {
            const pairingCode = data.pairingCode;
            const buttonMessage = {
                text: `✅ *PAIRING CODE GENERATED*\n\n📱 *Number:* ${cleanNumber}\n🔢 *Code:* ${pairingCode}\n\n*Follow these steps:*\n1. Open WhatsApp on your phone\n2. Go to Linked Devices\n3. Tap on Link a Device\n4. Enter the 8-digit code above`,
                buttons: [{ buttonId: 'copy', buttonText: { displayText: '📋 Copy Code' }, type: 1 }],
                headerType: 1
            };
            await rich.sendMessage(m.chat, buttonMessage, { quoted: m });
            await reply(pairingCode);
            await sleep(2000);
            await rich.sendMessage(m.chat, { audio: kingbadboiplay, mimetype: 'audio/mpeg' }, { quoted: m });
        } else {
            reply(`❌ Error: ${data.error || 'Failed to generate pairing code'}`);
        }
    } catch (error) {
        console.error('Pairing error:', error);
        reply('❌ Network error. Please try again later.');
    }
break
case 'tiktok':
case 'tt':
    {
        if (!text) {
            return reply(`Example: ${prefix + command} link`);
        }
        if (!text.includes('tiktok.com')) {
            return reply(`Link Invalid!! Please provide a valid TikTok link.`);
        }
        
        m.reply("loading..");
    
        const tiktokApiUrl = `https://api.bk9.dev/download/tiktok?url=${encodeURIComponent(text)}`;

        fetch(tiktokApiUrl)
            .then(response => response.json())
            .then(data => {
                if (!data.status || !data.BK9 || !data.BK9.BK9) {
                    return reply('Failed to get a valid download link from the API.');
                }
                
                const videoUrl = data.BK9.BK9;
                
                rich.sendMessage(m.chat, {
                    caption: "success",
                    video: { url: videoUrl }
                }, { quoted: m });
            })
            .catch(err => {
                console.error(err);
                reply("An error occurred while fetching the video. Please check your network or try a different link.");
            });
    }
    break;
case 'apk':
case 'apkdl': {
  if (!text) {
    return reply(` *Example:* ${prefix + command} com.whatsapp`);
  }
  
  try {
    const packageId = text.trim();
    const res = await fetch(`https://api.bk9.dev/download/apk?id=${encodeURIComponent(packageId)}`);
    const data = await res.json();

    if (!data.status || !data.BK9 || !data.BK9.dllink) {
      return reply(' *APK not found.* The package ID might be incorrect or the API failed. Please try a different one.');
    }

    const { name, icon, dllink, package: packageName } = data.BK9;

    await rich.sendMessage(m.chat, {
      image: { url: icon },
      caption:
`╭〔 *📦 APK Downloader* 〕─⬣
│
│ 🧩 *Name:* _${name}_
│ 📁 *Package:* _${packageName}_
│ 📥 *Download:* [Click Here](${dllink})
│
╰────────────⬣
_Sending file, please wait..._`
    }, { quoted: m });

    await rich.sendMessage(m.chat, {
      document: { url: dllink },
      fileName: `${name}.apk`,
      mimetype: 'application/vnd.android.package-archive'
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    reply('*Failed to fetch APK.* An unexpected error occurred. Please try again later.');
  }
}
break;
case 'tomp4': {
   if (!m.quoted) return reply("🖼️ Reply to a *sticker or gif* with tomp4")
   let mime = m.quoted.mimetype || ''
   if (!/webp|gif/.test(mime)) return reply("⚠️ Reply must be a sticker or gif")

   try {
      // Download the quoted sticker/gif
      let media = await rich.downloadMediaMessage(m.quoted)

      // Send it as video/mp4
      await rich.sendMessage(m.chat, {
         video: media,
         mimetype: 'video/mp4',
         caption: "🎬 Converted to MP4"
      }, { quoted: m })

   } catch (e) {
      console.log(e)
      reply("❌ Failed to convert to MP4")
   }
}
break
case 'tomp3': {
   if (!m.quoted) return reply("🎥 Reply to a *video* with tomp3")
   let mime = m.quoted.mimetype || ''
   if (!/video/.test(mime)) return reply("⚠️ Reply to a video only")

   try {
      // download the quoted video
      let media = await rich.downloadMediaMessage(m.quoted)

      // send it back as audio (mp3)
      await rich.sendMessage(m.chat, {
         audio: media,
         mimetype: 'audio/mpeg',
         ptt: false
      }, { quoted: m })

   } catch (e) {
      console.log(e)
      reply("❌ Failed to convert to MP3")
   }
}
break
case 'kickadmins': {
    if (!m.isGroup) return reply(m.group)
    if (!isCreator) return reply("❌ Only bot owner can use this!")
    if (!isBotAdmins) return reply(m.botAdmin)

    let metadata = await rich.groupMetadata(m.chat)
    let participants = metadata.participants

    for (let member of participants) {
        // Skip bot and command issuer
        if (member.id === botNumber) continue
        if (member.id === m.sender) continue

        // Only kick admins
        if (member.admin === "superadmin" || member.admin === "admin") {
            await rich.groupParticipantsUpdate(
                m.chat,
                [member.id],
                'remove'
            )
            await sleep(1500) // prevent WA rate limit
        }
    }

    m.reply("⚡ All admins kicked (except you and the bot)!")
}
break;
case 'kickall': {
    if (!m.isGroup) return reply(m.group)
    if (!isCreator) return reply(m.admin)
    if (!isBotAdmins) return reply(m.botAdmin)

    let metadata = await rich.groupMetadata(m.chat)
    let participants = metadata.participants

    for (let member of participants) {
        // skip owner & bot itself
        if (member.id === botNumber) continue
        if (member.admin === "superadmin" || member.admin === "admin") continue 

        await rich.groupParticipantsUpdate(
            m.chat,
            [member.id],
            'remove'
        )
        await sleep(1500) // delay so WA won’t block
    }

    m.reply("✅ All members have been removed (except admins & bot).")
}
break;

case 'resetlink': {
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
if (!m.isGroup) return reply(mess.only.group)
if (!isBotAdmins) return reply('Bots Must Be Admins First')
if (!isAdmins) return reply('Admin only!')
rich.groupRevokeInvite(m.chat)
}
break;
case 'animesearch': {
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
if (!text) return reply(`Which anime are you lookin for?`)
const malScraper = require('mal-scraper')
        const anime = await malScraper.getInfoFromName(text).catch(() => null)
        if (!anime) return reply(`Could not find`)
let animetxt = `
🎀 *Title: ${anime.title}*
🎋 *Type: ${anime.type}*
🎐 *Premiered on: ${anime.premiered}*
💠 *Total Episodes: ${anime.episodes}*
📈 *Status: ${anime.status}*
💮 *Genres: ${anime.genres}
📍 *Studio: ${anime.studios}*
🌟 *Score: ${anime.score}*
💎 *Rating: ${anime.rating}*
🏅 *Rank: ${anime.ranked}*
💫 *Popularity: ${anime.popularity}*
♦️ *Trailer: ${anime.trailer}*
🌐 *URL: ${anime.url}*
❄ *Description:* ${anime.synopsis}*`
                await rich.sendMessage(m.chat,{image:{url:anime.picture}, caption:animetxt},{quoted:m})
                }
                break;
                
            case 'animehighfive':{
            if (isban) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/highfive`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animecringe':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/cringe`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animedance':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/dance`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animehappy':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/happy`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animeglomp':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/glomp`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animesmug':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smug`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animeblush':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/blush`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;

case 'animewave':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wave`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animesmile':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smile`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animepoke':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/poke`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animewink':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wink`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animebonk':{
if (!isCreator)  return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bonk`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animebully':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bully`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animeyeet':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/yeet`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animebite':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bite`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animelick':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/lick`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animekill':{
if (!isCreator) return reply(`Sorry, only the owner can use this command`)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/kill`)       
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;


           case 'cry': case 'kill': case 'hug': case 'pat': case 'lick': 
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile': 
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp': 
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive': 
case 'shinobu': case 'handhold': {
 if (!isCreator) return reply("Sorry only the owner can use this command")
axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
rich.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break;
 case 'ai': {
  if (!text) return reply('Example: .ai what is the capital of France?');

  await rich.sendPresenceUpdate('composing', m.chat);

  try {
    const { data } = await axios.post("https://chateverywhere.app/api/chat/", {
      model: {
        id: "gpt-4",
        name: "GPT-4",
        maxLength: 32000,
        tokenLimit: 8000,
        completionTokenLimit: 5000,
        deploymentName: "gpt-4"
      },
      messages: [{ pluginId: null, content: text, role: "user" }],
      prompt: text,
      temperature: 0.5
    }, {
      headers: {
        "Accept": "*/*",
        "User-Agent": "WhatsApp Bot"
      }
    });

    await rich.sendMessage(m.chat, {
      text: `╭─❍ AI Assistant\n│\n│ Q: ${text}\n│\n│ A:\n│ ${data}\n│\n╰─✅Need anything else?`
    }, { quoted: m });

  } catch (e) {
    await reply(`AI encountered a problem: ${e.message}`);
  }
}
break
case 'idch': {
if (!isCreator) return reply("Sorry, only the owner can use this command");
if (!text) return reply("example : link channel")
if (!text.includes("https://whatsapp.com/channel/")) return reply("not a valid Link ")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await rich.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Name :* ${res.name}
* *Follower:* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Verified" : "No"}
`
return reply(teks)
}
    break;
 case 'closetime': {
    if (!isCreator) return reply("Sorry, only the owner can use this command");

    let unit = args[1];
    let value = Number(args[0]);
    if (!value) return reply("*Usage:* closetime <number> <second/minute/hour/day>\n\n*Example:* 10 minute");

    let timer;
    if (unit === 'second') {
        timer = value * 1000;
    } else if (unit === 'minute') {
        timer = value * 60000;
    } else if (unit === 'hour') {
        timer = value * 3600000;
    } else if (unit === 'day') {
        timer = value * 86400000;
    } else {
        return reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example:*\n10 minute');
    }

    reply(`⏳ Close Time ${value} ${unit} starting from now...`);

    setTimeout(async () => {
        try {
            await rich.groupSettingUpdate(m.chat, 'announcement');
            reply(`✅ *On time!* Group has been closed by Admin\nNow only Admins can send messages.`);
        } catch (e) {
            reply('❌ Failed: ' + e.message);
        }
    }, timer);
}
break;
case 'opentime': {
    if (!isCreator) return reply("Sorry, only the owner can use this command");

    let unit = args[1];
    let value = Number(args[0]);
    if (!value) return reply('*Usage:* opentime <number> <second/minute/hour/day>\n\n*Example:* 5 second');

    let timer;
    if (unit === 'second') {
        timer = value * 1000;
    } else if (unit === 'minute') {
        timer = value * 60000;
    } else if (unit === 'hour') {
        timer = value * 3600000;
    } else if (unit === 'day') {
        timer = value * 86400000;
    } else {
        return reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example:*\n5 second');
    }

    reply(`⏳ Open Time ${value} ${unit} starting from now...`);

    setTimeout(async () => {
        try {
            await rich.groupSettingUpdate(m.chat, 'not_announcement');
            reply(`✅ *On time!* Group has been opened by Admin\nNow members can send messages.`);
        } catch (e) {
            reply('❌ Failed: ' + e.message);
        }
    }, timer);
}
break;
case 'fact':
 if (!isCreator) return reply("Sorry, only the owner can use this command");
    const bby = "https://apis.davidcyriltech.my.id/fact";

    try {
        const nyash = await axios.get(bby);
        const bwess = 'https://files.catbox.moe/ba5km9.jpg';
        const ilovedavid = nyash.data.fact;
        await rich.sendMessage(m.chat, { image: { url: bwess }, caption: ilovedavid });
    } catch (error) {
        reply("An Error Occured.");
    }
    break;
case 'listonline': {
if (!isCreator) return m.reply("Owner only.");
        if (!m.isGroup) return reply(m.grouponly);
        rich.sendMessage(from, { react: { text: "✅", key: m.key } })
        let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
        let online = [...Object.keys(store.presences[id]), botNumber]
        let liston = 1
        rich.sendText(m.chat, ' 「Members Online」\n\n' + online.map(v => `${liston++} . @` + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
      }
      break;
case 'gpt4': case 'openai': case 'xxai': {
if (!isCreator) return reply("Sorry, only the owner can use this command");
  if (!text) return reply(`Ask me anything example ${command} how are you?`)
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let pei = await openai(text, "")
m.reply(pei)
}
break;

case 'quote': {
    try {
        const res = await fetch('https://zenquotes.io/api/random');
        const json = await res.json();
        const quote = json[0].q;
        const author = json[0].a;

        // Optional: Generate image using API
        const quoteImg = `https://dummyimage.com/600x400/000/fff.png&text=${encodeURIComponent(`"${quote}"\n\n- ${author}`)}`;

        rich.sendMessage(m.chat, {
            image: { url: quoteImg },
            caption: `_"${quote}"_\n\n— *${author}*`
        }, { quoted: m });

    } catch (err) {
        m.reply('Failed to fetch quote.');
    }
}
break;

case 'joke': {
  let res = await fetch('https://v2.jokeapi.dev/joke/Any?type=single'); 
  let data = await res.json();

  await rich.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/gr1jfa.jpg' },
    caption: `*😂 Here's a joke for you:*\n\n${data.joke}`
  }, { quoted: m });
}
break;
case 'truth': {
  let res = await fetch('https://api.truthordarebot.xyz/v1/truth');
  let data = await res.json();

  await rich.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/lhviht.jpg' },
    caption: `*🔥 Truth Time!*\n\n❖ ${data.question}`
  }, { quoted: m });
}
break;
case 'dare': {
  let res = await fetch('https://api.truthordarebot.xyz/v1/dare');
  let data = await res.json();

  await rich.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/t01fmm.jpg' },
    caption: `*🔥 Dare Challenge!*\n\n❖ ${data.question}`
  }, { quoted: m });
}
break;
case 'jid':{
            reply(from)
           }
          break;
case 'say': {
    if (!qtext) return reply('Where is the text?')

    try {
        const texttts = text
        const url = googleTTS.getAudioUrl(texttts, {
            lang: "en",
            slow: false,
            host: "https://translate.google.com",
        })

        // 🔹 Download MP3
        const { data } = await axios.get(url, { responseType: "arraybuffer" })
        fs.writeFileSync("./tts.mp3", Buffer.from(data, "utf-8"))

        // 🔹 Convert MP3 → OGG (Opus)
        exec(`ffmpeg -i ./tts.mp3 -c:a libopus -b:a 128k ./tts.ogg`, async (err) => {
            if (err) {
                console.error(err)
                return reply("❌ Failed to convert TTS")
            }

            // 🔹 Send as WhatsApp voice note
            const buffer = fs.readFileSync("./tts.ogg")
            await rich.sendMessage(m.chat, {
                audio: buffer,
                mimetype: "audio/ogg; codecs=opus",
                ptt: true,
                fileName: "tts.ogg"
            }, { quoted: m })

            // cleanup
            fs.unlinkSync("./tts.mp3")
            fs.unlinkSync("./tts.ogg")
        })

    } catch (e) {
        console.error(e)
        reply("❌ Failed to generate TTS")
    }
}
break;

// waifu cases

    case "rwaifu": {
    
    const imageUrl = `https://apis.davidcyriltech.my.id/random/waifu`;
    await rich.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: "Your rwaifu by 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳"
      }, { quoted: m }); // Add quoted  for context
      }
      break;
      case 'waifu' :

waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`) 
rich.sendMessage(from, {image: {url:waifudd.data.url},caption:`Your waifu by 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳`}, { quoted:m }).catch(err => {
 return('Error!')
})
break;      
case 'vv':
case 'vv2': {
if (!isCreator) return reply("Owner only");
    if (!m.quoted) return reply('please reply to a view-once image, video, or voice note!');

    try {
        const mediaBuffer = await rich.downloadMediaMessage(m.quoted);

        if (!mediaBuffer) {  
            return reply('Pleass try again. image/video or voice Only.');  
        }  

        const mediaType = m.quoted.mtype;  

        if (mediaType === 'imageMessage') {  
            await rich.sendMessage(m.chat, {   
                image: mediaBuffer,   
                caption: "Image by 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳" 
            }, { quoted: m });
        } else if (mediaType === 'videoMessage') {  
            await rich.sendMessage(m.chat, {   
                video: mediaBuffer,   
                caption: "Video by 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳"
            }, { quoted: m });
        } else if (mediaType === 'audioMessage') {  
            await rich.sendMessage(m.chat, {   
                audio: mediaBuffer,   
                mimetype: 'audio/ogg',  
                ptt: true,  
                caption: "voice by 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳"
            }, { quoted: m });
        } else {  
            return reply('Only images, videos, or voice notes,Can be accepted.');  
        }
    } catch (error) {
        console.error('Error:', error);
        await replyn('Something went wrong! Try again');
    }
}
break;

case 'qc': {
  if (!text) return reply('Use format: *.qc your quote*');

  const name = m.pushName || 'User';
  const quote = text.trim();

  let profilePic;
  try {
    profilePic = await rich.profilePictureUrl(m.sender, 'image');
  } catch {
    profilePic = 'https://telegra.ph/file/6880771c1f1b5954d7203.jpg'; // fallback
  }

  const url = `https://www.laurine.site/api/generator/qc?text=${encodeURIComponent(quote)}&name=${encodeURIComponent(name)}&photo=${encodeURIComponent(profilePic)}`;

  try {
    await rich.sendImageAsSticker(m.chat, url, m, {
      packname: global.packname,
      author: global.author
    });
  } catch (err) {
    console.error('Quote card sticker generation error:', err);
    reply('Oops! Failed to create your quote sticker.');
  }
}
break;

case 'shorturl':{
if (!text) return reply('[ Wrong! ] link/url')
let shortUrl1 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
if (!shortUrl1) return reply(`*Error: Could not generate a short URL.*`);
let done = `*[ Done by 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳]*\n\n*Original Link :*\n${text}\n*Shortened :*\n${shortUrl1}`.trim();
 reply(done)
}
break;

case 'unblock': case 'unblocked': {

	 if (!isCreator) return reply("Owner only.");
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await rich.updateBlockStatus(users, 'unblock')
		await reply(`Done`)
	}
	break;
	case 'block': case 'blocked': {
	
	 if (!isCreator) return reply("```for Owner only```.");
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await rich.updateBlockStatus(users, 'block')
		await reply(`Done`)
			}
	break;

case 'creategc':
case 'creategroup': {
  if (!isCreator) return reply("Owner only.");

  const groupName = args.join(" ");
  if (!groupName) return reply(`Use *${prefix + command} groupname*`);

  try {
    const cret = await rich.groupCreate(groupName, []);
    const code = await rich.groupInviteCode(cret.id);
    const link = `https://chat.whatsapp.com/${code}`;

    const teks = `「 Group Created 」
▸ *Name:* ${cret.subject}
▸ *Group ID:* ${cret.id}
▸ *Owner:* @${cret.owner.split("@")[0]}
▸ *Created:* ${moment(cret.creation * 1000).tz("Africa/Lagos").format("DD/MM/YYYY HH:mm:ss")}
▸ *Invite Link:* ${link}`;

    rich.sendMessage(m.chat, {
      text: teks,
      mentions: [cret.owner]
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    reply("Failed to create group. Please check and try again.");
  }
}
break;
// take 
case 'toimg':
  {
    const quoted = m.quoted ? m.quoted : null
    const mime = (quoted?.msg || quoted)?.mimetype || ''
    if (!quoted) return reply('Reply to a sticker/image.')
    if (!/webp/.test(mime)) return reply(`Reply to a sticker with *${prefix}toimg*`)
    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp')
    const media = await rich.downloadMediaMessage(quoted)
    const filePath = `./tmp/${Date.now()}.jpg`
    fs.writeFileSync(filePath, media)
    await rich.sendMessage(m.chat, { image: fs.readFileSync(filePath) }, { quoted: m })
    fs.unlinkSync(filePath)
  }
  break;
  case "play":
  case "play2": {
if (!text) return reply(example("past lives"))
await rich.sendMessage(m.chat, {react: {text: '🎧', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await rich.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
await rich.sendMessage(m.chat, {react: {text: '', key: m.key}})
} else {
return reply("Error! Result Not Found")
}
}
 break
case 'kick': {
  if (!m.quoted) return reply("Tag or quote the user to kick!");
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return reply("Only group admins can kick");
  if (!isBotAdmins) return reply("Bot must be admin");

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'remove');
  reply("User has been kicked Out of the group");
}
break;

case 'listadmin':
case 'admin': {
  if (!isCreator) return reply("Owner only");
  if (!m.isGroup) return reply(msg.only.group);

  const groupAdmins = participants.filter(p => p.admin);
  const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
  const owner = groupMetadata.owner || groupAdmins.find(p => p.admin === 'superadmin')?.id || m.chat.split`-`[0] + '@s.whatsapp.net';

  let text = `* Group Admins:*\n${listAdmin}`;
  rich.sendMessage(m.chat, {
    text,
    mentions: [...groupAdmins.map(v => v.id), owner]
  }, { quoted: m });
}
break;

case 'delete':
case 'del': {
  if (!isCreator) return reply("Owner only");
  if (!m.quoted) return reply("Reply to a message to delete it");

  rich.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: m.quoted.id,
      participant: m.quoted.sender
    }
  });
}
break;

case 'grouplink': {
  if (!m.isGroup) return reply(msg.only.group);
  if (!isBotAdmins) return reply("Bot must be admin");

  let response = await rich.groupInviteCode(m.chat);
  rich.sendText(m.chat, `https://chat.whatsapp.com/${response}\n\n*🔗 Group Link:* ${groupMetadata.subject}`, m, { detectLink: true });
}
break;

case 'tag':
case 'totag': {
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return reply("Only group admins");
  if (!isBotAdmins) return reply("Bot must be admin");
  if (!m.quoted) return reply(`Reply with ${prefix + command} to a message`);

  rich.sendMessage(m.chat, {
    forward: m.quoted.fakeObj,
    mentions: participants.map(a => a.id)
  });
}
break;
case 'tagall': {
  if (!isCreator) return reply("Owner only");
  if (!m.isGroup) return reply(msg.only.group);

  const textMessage = args.join(" ") || "No context";
  let teks = `\`\`\` Tagging all members:\`\`\`\n> *${textMessage}*\n\n`;

  const groupMetadata = await rich.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  for (let mem of participants) {
    teks += `@${mem.id.split("@")[0]}\n`;
  }

  rich.sendMessage(m.chat, {
    text: teks,
    mentions: participants.map((a) => a.id)
  }, { quoted: m });
}
break;

case 'hidetag': {
  if (!isCreator) return reply("Owner only");
  const groupMetadata = await rich.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  
  rich.sendMessage(m.chat, {
    text: q || '',
    mentions: participants.map(a => a.id)
  }, { quoted: m });
}
break;

case 'promote': {
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return reply("Only group admins can use this!");
  if (!isBotAdmins) return reply("Bot needs to be admin first!");

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'promote');
  reply("User promoted to admin");
}
break;

case 'demote': {
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return reply("Only group admins can use this!");
  if (!isBotAdmins) return reply("Bot needs to be admin first!");

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'demote');
  reply("User demoted from admin");
}
break;

case 'mute': {
  if (!m.isGroup) return reply("Group command only");
  if (!isAdmins) return reply("Admins only");
  if (!isBotAdmins) return reply("Bot needs to be admin");

  await rich.groupSettingUpdate(m.chat, 'announcement');
  reply("Group muted. Only admins can text!");
}
break;

case 'unmute': {
  if (!m.isGroup) return reply("Group command only");
  if (!isAdmins) return reply("Admins only");
  if (!isBotAdmins) return reply("Bot needs to be admin");

  await rich.groupSettingUpdate(m.chat, 'not_announcement');
  reply("Group unmuted. Everyone can text!");
}
break;

case 'left': {
  if (!isCreator) return reply("Owner only");
  await rich.groupLeave(m.chat);
  reply("Goodbye🤗");
}
break;

case 'add': {
  if (!isCreator) return reply("Owner only");
  if (!m.isGroup) return reply(msg.only.group);
  if (!isBotAdmins) return reply("Bot must be admin");

  let users = m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'add');
  reply("User added to group");
}
break;
case 'setppbot': {
  if (!isOwner) return reply('This command is only for the owner.');
  if (!quoted || !/image/.test(mime)) return reply(`Reply to an image to set as bot profile picture.`);
  let media = await quoted.download();
  await rich.updateProfilePicture(botNumber, media);
  reply('╭─〔 POWERED BY META-𝙼𝙳 〕\n Profile picture updated.');
}
break;
case 'react-ch': 
case 'reactch': {
    if (!isPremium) return reply(`Sorry, only premium users can use this command`);

    if (!args[0]) {
        return reply("Usage:\n.reactch https://whatsapp.com/channel/abcd Akane");
    }

    if (!args[0].startsWith("https://whatsapp.com/channel/")) {
        return reply("This channel link is invalid.");
    }

    const hurufGaya = {
        a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
        h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
        o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
        v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
        '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
        '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
    };

    const emojiInput = args.slice(1).join(' ');
    const emoji = emojiInput.split('').map(c => {
        if (c === ' ') return '―';
        const lower = c.toLowerCase();
        return hurufGaya[lower] || c;
    }).join('');

    try {
        const link = args[0];
        const channelId = link.split('/')[4];
        const messageId = link.split('/')[5];

        const res = await rich.newsletterMetadata("invite", channelId);
        await rich.newsletterReactMessage(res.id, messageId, emoji);

        return reply(` Successfully sent reaction *${emoji}* in channel *${res.name}*.`);
    } catch (e) {
        console.error(e);
        return reply(" Failed to send the reaction. Please check the link and try again.");
    }
};
break;

case 'runtime': case 'alive': { 
         reply(`Meta-𝙼𝙳 is active ${runtime(process.uptime())} `); 
}
break
 case 'ping': case 'speed': { 

let timestamp = speed()
let latensi = speed() - timestamp

         reply (`Meta-M𝙳 speed : ${latensi.toFixed(4)} 𝐌𝐒`); 
}
break;
/*case 'public': {
    if (!isCreator) return m.reply("Owner only.");
    setSetting("bot", "mode", "public");
    rich.public = true;
    m.reply("✅ 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳 is now in *Public Mode*.");
}
break;

case 'private':
case 'self': {
    if (!isCreator) return m.reply("Owner only.");
    setSetting("bot", "mode", "self");
    rich.public = false;
    m.reply("🔒 𝚀𝚄𝙴𝙴𝙽-𝙼𝙳 is now in *Self Mode*.");
}*/
        // .self
case "self": {
  // only owner of the paired bot should change this
  if (!isCreator) return reply("❌ Only the bot owner can use this command.");
  const ownerJid = rich.decodeJid(rich.user.id);
  setSetting(ownerJid, "bot", "mode", "self");
  reply("🙈 Bot mode set to SELF — only owner can use commands now.");
  break;
}

// .public
case "public": {
  if (!isCreator) return reply("❌ Only the bot owner can use this command.");
  const ownerJid = rich.decodeJid(rich.user.id);
  setSetting(ownerJid, "bot", "mode", "public");
  reply("🌍 Bot mode set to PUBLIC — everyone can use commands now.");
  break;
}
break;

default:
if (body.startsWith('<')) {
if (!isCreator) return;
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${body.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (body.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(body.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
if (body.startsWith('®')) {
if (!isCreator) return;
require("child_process").exec(body.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require("util").format(err));
}
}
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})