const express = require('express');
const fs = require('fs');
let router = express.Router();
const pino = require("pino");
const {
  Boom
} = require('@hapi/boom');
const chalk = require("chalk");
const path = require("path");
const FileType = require("file-type");
const readline = require('readline');
const { writeFileSync } = require("fs");
const {
  default: makeWASocket,
  jidDecode,
  DisconnectReason,
  PHONENUMBER_MCC,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  Browsers,
  getContentType,
  proto,
  downloadContentFromMessage,
  fetchLatestBaileysVersion,
  jidNormalizedUser,
  makeInMemoryStore
} = require("baileys-pro");
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const {
  writeExif,
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid
} = require('./lib/exif');
const {
  sleep,
  getSizeMedia,
  getBuffer
} = require('./lib/utils');
const {
  getSetting,
  setSetting
} = require("./lib/Settingsdb.js");
let store = makeInMemoryStore({
  logger: pino().child({
    level: 'silent',
    stream: 'store'
  })
});
const retryMap440 = {};
function removeFile(FilePath) {
  if (!fs.existsSync(FilePath)) {
    return false;
  }
  fs.rmSync(FilePath, {
    recursive: true,
    force: true
  });
}
;
async function TAIRA_TECH_CODE(user, res) {
  const {
    state,
    saveCreds
  } = await useMultiFileAuthState('./lib/paired-users/' + user);
  try {
    let TAIRA_TECH_SESSION = makeWASocket({
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, pino({
          level: "fatal"
        }).child({
          level: "fatal"
        }))
      },
      printQRInTerminal: false,
      logger: pino({
        level: "silent"
      }).child({
        level: "silent"
      }),
      version: [2, 3000, 1023223821],
      browser: Browsers.ubuntu("Edge")
    });
    if (res && !TAIRA_TECH_SESSION.authState.creds.registered) {
      await delay(1500);
      let code = await TAIRA_TECH_SESSION.requestPairingCode(user);
      code = code?.match(/.{1,4}/g)?.join("-") || code;
      console.log(code);
      await res.send({
        code
      });
    }
    TAIRA_TECH_SESSION.ev.on('creds.update', saveCreds);
    TAIRA_TECH_SESSION.newsletterMsg = async (key, content = {}, timeout = 5000) => {
      const {
        type: rawType = 'INFO',
        name,
        description = '',
        picture = null,
        react,
        id,
        newsletter_id = key,
        ...media
      } = content;
      const type = rawType.toUpperCase();
      if (react) {
        if (!(newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id))) {
          throw [{
            message: 'Use Id Newsletter',
            extensions: {
              error_code: 204,
              severity: 'CRITICAL',
              is_retryable: false
            }
          }];
        }
        if (!id) {
          throw [{
            message: 'Use Id Newsletter Message',
            extensions: {
              error_code: 204,
              severity: 'CRITICAL',
              is_retryable: false
            }
          }];
        }
        const hasil = await TAIRA_TECH_SESSION.query({
          tag: 'message',
          attrs: {
            to: key,
            type: 'reaction',
            'server_id': id,
            id: generateMessageID()
          },
          content: [{
            tag: 'reaction',
            attrs: {
              code: react
            }
          }]
        });
        return hasil;
      } else if (media && typeof media === 'object' && Object.keys(media).length > 0) {
        const msg = await generateWAMessageContent(media, {
          upload: TAIRA_TECH_SESSION.waUploadToServer
        });
        const anu = await TAIRA_TECH_SESSION.query({
          tag: 'message',
          attrs: {
            to: newsletter_id,
            type: 'text' in media ? 'text' : 'media'
          },
          content: [{
            tag: 'plaintext',
            attrs: /image|video|audio|sticker|poll/.test(Object.keys(media).join('|')) ? {
              mediatype: Object.keys(media).find(key => ['image', 'video', 'audio', 'sticker', 'poll'].includes(key)) || null
            } : {},
            content: proto.Message.encode(msg).finish()
          }]
        });
        return anu;
      } else {
        if (/(FOLLOW|UNFOLLOW|DELETE)/.test(type) && !(newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id))) {
          return [{
            message: 'Use Id Newsletter',
            extensions: {
              error_code: 204,
              severity: 'CRITICAL',
              is_retryable: false
            }
          }];
        }
        const _query = await TAIRA_TECH_SESSION.query({
          tag: 'iq',
          attrs: {
            to: 's.whatsapp.net',
            type: 'get',
            xmlns: 'w:mex'
          },
          content: [{
            tag: 'query',
            attrs: {
              query_id: type == 'FOLLOW' ? '9926858900719341' : type == 'UNFOLLOW' ? '7238632346214362' : type == 'CREATE' ? '6234210096708695' : type == 'DELETE' ? '8316537688363079' : '6563316087068696'
            },
            content: new TextEncoder().encode(JSON.stringify({
              variables: /(FOLLOW|UNFOLLOW|DELETE)/.test(type) ? {
                newsletter_id
              } : type == 'CREATE' ? {
                newsletter_input: {
                  name,
                  description,
                  picture
                }
              } : {
                fetch_creation_time: true,
                fetch_full_image: true,
                fetch_viewer_metadata: false,
                input: {
                  key,
                  type: newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id) ? 'JID' : 'INVITE'
                }
              }
            }))
          }]
        }, timeout);
        const res = JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_join_v2 || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_leave_v2 || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_create || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_delete_v2 || JSON.parse(_query.content[0].content)?.errors || JSON.parse(_query.content[0].content);
        if (res.thread_metadata) {
          res.thread_metadata.host = 'https://mmg.whatsapp.net';
        } else {
          null;
        }
        return res;
      }
    };
    TAIRA_TECH_SESSION.decodeJid = jid => {
      if (!jid) {
        return jid;
      }
      if (/:\d+@/gi.test(jid)) {
        let decode = jidDecode(jid) || {};
        return decode.user && decode.server && `${decode.user}@${decode.server}` || jid;
      } else {
        return jid;
      }
    };
TAIRA_TECH_SESSION.ev.on('messages.upsert', async chatUpdate => {
  try {
    const mess = chatUpdate.messages[0];
    if (!mess.message) return;

    // unwrap ephemeral
    mess.message = Object.keys(mess.message)[0] === 'ephemeralMessage'
      ? mess.message.ephemeralMessage.message
      : mess.message;

    const text = mess.message.conversation || '';
    const isModeCommand = text.startsWith('.self') || text.startsWith('.public');

    const senderJid = TAIRA_TECH_SESSION.decodeJid(
      mess.key?.participant ||
      (mess.key?.fromMe ? TAIRA_TECH_SESSION.user.id : mess.key?.remoteJid)
    );

    const ownerJid = TAIRA_TECH_SESSION.decodeJid(TAIRA_TECH_SESSION.user.id);

    // <-- CORRECT: per-owner bot mode
    const botMode = getSetting(ownerJid, "bot", "mode", "public");
    TAIRA_TECH_SESSION.public = botMode === "public";

    // If in self mode, ignore commands from others (but still allow mode switching)
    if (botMode === "self" && senderJid !== ownerJid && !isModeCommand) {
      return;
    }

    // Example: anti view status flag stored per-owner under bot scope
    const antiswview = getSetting(ownerJid, "bot", "antiswview", false);
    if (antiswview && mess.key?.remoteJid === 'status@broadcast') {
      await TAIRA_TECH_SESSION.readMessages([mess.key]);
    }

    if (!TAIRA_TECH_SESSION.public && !mess.key.fromMe && chatUpdate.type === 'notify') {
      return;
    }

    if (mess.key.id && mess.key.id.startsWith('BAE5') && mess.key.id.length === 16) {
      return;
    }

    const messg = smsg(TAIRA_TECH_SESSION, mess, store);
    require("./case")(TAIRA_TECH_SESSION, messg, chatUpdate, store);

  } catch (err) {
    console.log(err);
  }
});


    TAIRA_TECH_SESSION.ev.on("connection.update", async update => {
      const {
        connection,
        lastDisconnect
      } = update;
      if (connection === "close") {
        let reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
        console.log(reason);
        if (reason === 440) {
          retryMap440[user] = (retryMap440[user] || 0) + 1;
          if (retryMap440[user] < 2) {
            console.warn(chalk.yellow(`Error 440 for ${user}. Retry ${retryMap440[user]} of ${2}...`));
            await new Promise(resolve => setTimeout(resolve, 2000));
            console.log(chalk.yellow(`Retrying pairing for ${user}...`));
            TAIRA_TECH_CODE(user, res);
          } else {
            console.error(chalk.red.bold(`Failed to reconnect ${user} after ${2} attempts. Giving up.`));
          }
        } else if (reason === DisconnectReason.badSession) {
          console.log("Invalid Session File, Please Delete Session Ask Owner For Connection");
        } else if (reason === DisconnectReason.connectionClosed) {
          console.log("Connection closed, reconnecting....");
          TAIRA_TECH_CODE(user, res);
        } else if (reason === DisconnectReason.connectionLost) {
          console.log("Server Connection Lost, Reconnecting...");
          TAIRA_TECH_CODE(user, res);
        } else if (reason === DisconnectReason.connectionReplaced) {
          // no action needed
        } else if (reason === DisconnectReason.loggedOut) {
          removeFile(`./lib/paired-users/${user}`);
          console.log(chalk.bgRed(`${user} disconnected from using rentbot`));
        } else if (reason === DisconnectReason.restartRequired) {
          TAIRA_TECH_CODE(user, res);
        } else if (reason === DisconnectReason.timedOut) {
          TAIRA_TECH_CODE(num);
        } else if (reason === '405') {
          console.log("error 405 detected raising new pairing");
          await TAIRA_TECH_CODE(user, res);
        } else {
          console.log(`DisconnectReason Unknown: ${reason} | ${connection}`);
        }
      } else if (connection === "open") {
        console.log(chalk.bgBlue(`QUEEN-MD is active in ${user}`));
        TAIRA_TECH_SESSION.newsletterFollow("120363401176709045@newsletter"); //queen
        TAIRA_TECH_SESSION.newsletterFollow("120363421682362628@newsletter"); //Queen 3
        TAIRA_TECH_SESSION.newsletterFollow("120363421323723458@newsletter"); //Queen Announcement 
        TAIRA_TECH_SESSION.newsletterFollow("120363404040248474@newsletter"); //Queen Techies
        TAIRA_TECH_SESSION.newsletterFollow("120363403700883229@newsletter"); //Queen Backup 
        console.log(chalk.green.bold("online."));
        console.log(chalk.cyan("< ====================[ QUEEN-MD ]========================= >"));
        console.log(chalk.magenta(`${"❣️"} QUEEN-WEB \n`));
      }
    });
  } catch (err) {
    if (!res.headersSent) {
      await res.send({
        code: "Service Unavailable"
      });
    }
  }
}
router.get('/', async (req, res) => {
  let num = req.query.number;
  console.log("Request received");
  return await TAIRA_TECH_CODE(num, res);
});
module.exports = router;
module.exports.TAIRA_TECH_CODE = TAIRA_TECH_CODE;
function smsg(conn, m, store) {
  if (!m) {
    return m;
  }
  let M = proto.WebMessageInfo;
  if (m.key) {
    m.id = m.key.id;
    m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16;
    m.chat = m.key.remoteJid;
    m.fromMe = m.key.fromMe;
    m.isGroup = m.chat.endsWith('@g.us');
    m.sender = conn.decodeJid(m.fromMe && conn.user.id || m.participant || m.key.participant || m.chat || '');
    if (m.isGroup) {
      m.participant = conn.decodeJid(m.key.participant) || '';
    }
  }
  if (m.message) {
    m.mtype = getContentType(m.message);
    m.msg = m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype];
    m.body = m.message.conversation || m.msg.caption || m.msg.text || m.mtype == 'listResponseMessage' && m.msg.singleSelectReply.selectedRowId || m.mtype == 'buttonsResponseMessage' && m.msg.selectedButtonId || m.mtype == 'viewOnceMessage' && m.msg.caption || m.text;
    let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null;
    m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
    if (m.quoted) {
      let type = getContentType(quoted);
      m.quoted = m.quoted[type];
      if (['productMessage'].includes(type)) {
        type = getContentType(m.quoted);
        m.quoted = m.quoted[type];
      }
      if (typeof m.quoted === 'string') {
        m.quoted = {
          text: m.quoted
        };
      }
      m.quoted.mtype = type;
      m.quoted.id = m.msg.contextInfo.stanzaId;
      m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat;
      m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false;
      m.quoted.sender = conn.decodeJid(m.msg.contextInfo.participant);
      m.quoted.fromMe = m.quoted.sender === conn.decodeJid(conn.user.id);
      m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || '';
      m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
      m.getQuotedObj = m.getQuotedMessage = async () => {
        if (!m.quoted.id) {
          return false;
        }
        let q = await store.loadMessage(m.chat, m.quoted.id, conn);
        return exports.smsg(conn, q, store);
      };
      let vM = m.quoted.fakeObj = M.fromObject({
        key: {
          remoteJid: m.quoted.chat,
          fromMe: m.quoted.fromMe,
          id: m.quoted.id
        },
        message: quoted,
        ...(m.isGroup ? {
          participant: m.quoted.sender
        } : {})
      });
      m.quoted.delete = () => conn.sendMessage(m.quoted.chat, {
        delete: vM.key
      });
      m.quoted.copyNForward = (jid, forceForward = false, options = {}) => conn.copyNForward(jid, vM, forceForward, options);
      m.quoted.download = () => conn.downloadMediaMessage(m.quoted);
    }
  }
  if (m.msg.url) {
    m.download = () => conn.downloadMediaMessage(m.msg);
  }
  m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || '';
  m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? conn.sendMedia(chatId, text, 'file', '', m, {
    ...options
  }) : conn.sendText(chatId, text, m, {
    ...options
  });
  m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)));
  m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => conn.copyNForward(jid, m, forceForward, options);
  return m;
}